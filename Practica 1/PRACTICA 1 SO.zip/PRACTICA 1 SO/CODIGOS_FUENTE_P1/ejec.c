#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

int recibido = 0;
int pidEjec, pidA, pidB, pidX, pidY, pidZ;

void señalA(int s)
{
    recibido = 1;
}

void alarmaZ(int s)
{
    kill(pidA, SIGUSR1);
}

void morirHoja(int s)
{
    if (getpid() == pidX)
        printf("Soy X (%d) y muero\n", pidX);
    if (getpid() == pidY)
        printf("Soy Y (%d) y muero\n", pidY);
    if (getpid() == pidZ)
        printf("Soy Z (%d) y muero\n", pidZ);
    exit(0);
}

void morirB(int s)
{
    kill(pidZ, SIGUSR2);
    wait(NULL);
    kill(pidY, SIGUSR2);
    wait(NULL);
    kill(pidX, SIGUSR2);
    wait(NULL);
    printf("Soy B (%d) y muero\n", pidB);
    exit(0);
}

void ejecutarPstree(void)
{
    if (fork() == 0)
        execlp("pstree", "pstree", (char *)0);
    wait(NULL);
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        printf("Uso: %s segundos\n", argv[0]);
        return 1;
    }

    pidEjec = getpid();
    printf("Soy el proceso ejec: mi pid es %d\n", pidEjec);
    fflush(stdout);

    if ((pidA = fork()) == 0) {
        pidA = getpid();
        signal(SIGUSR1, señalA);
        printf("Soy el proceso A: mi pid es %d. Mi padre es %d\n",
               pidA, getppid());
        fflush(stdout);

        if ((pidB = fork()) == 0) {
            pidB = getpid();
            signal(SIGUSR2, morirB);
            printf("Soy el proceso B: mi pid es %d. Mi padre es %d. Mi abuelo es %d\n",
                   pidB, getppid(), pidEjec);
            fflush(stdout);

            if ((pidX = fork()) == 0) {
                pidX = getpid();
                signal(SIGUSR2, morirHoja);
                printf("Soy el proceso X: mi pid es %d. Mi padre es %d. Mi abuelo es %d. Mi bisabuelo es %d\n",
                       pidX, pidB, pidA, pidEjec);
                fflush(stdout);
                while (1)
                    pause();
            }

            if ((pidY = fork()) == 0) {
                pidY = getpid();
                signal(SIGUSR2, morirHoja);
                printf("Soy el proceso Y: mi pid es %d. Mi padre es %d. Mi abuelo es %d. Mi bisabuelo es %d\n",
                       pidY, pidB, pidA, pidEjec);
                fflush(stdout);
                while (1)
                    pause();
            }

            if ((pidZ = fork()) == 0) {
                pidZ = getpid();
                signal(SIGALRM, alarmaZ);
                signal(SIGUSR2, morirHoja);
                printf("Soy el proceso Z: mi pid es %d. Mi padre es %d. Mi abuelo es %d. Mi bisabuelo es %d\n",
                       pidZ, pidB, pidA, pidEjec);
                fflush(stdout);
                alarm(atoi(argv[1]));
                pause();
                while (1)
                    pause();
            }

            while (1)
                pause();
        }

        while (!recibido)
            pause();
        ejecutarPstree();
        kill(pidB, SIGUSR2);
        wait(NULL);
        printf("Soy A (%d) y muero\n", pidA);
        exit(0);
    }

    wait(NULL);
    printf("Soy ejec (%d) y muero\n", pidEjec);
    return 0;
}
