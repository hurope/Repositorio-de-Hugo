#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

void nada(int s)
{
}

int main(int argc, char *argv[])
{
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);
    int i, j, pid;

    for (i = 0; i < y; i++) {
        pid = fork();

        if (pid == 0) {
            for (j = 1; j < x; j++) {
                pid = fork();

                if (pid != 0) {
                    wait(NULL);
                    exit(0);
                }
            }

            signal(SIGALRM, nada);
            alarm(10);
            pause();
            exit(0);
        }
    }

    for (i = 0; i < y; i++)
        wait(NULL);

    return 0;
}
