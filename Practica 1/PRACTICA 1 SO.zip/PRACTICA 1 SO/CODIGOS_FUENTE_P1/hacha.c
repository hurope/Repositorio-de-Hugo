#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    int archivo, salida, tubo[2], pid;
    int tam = atoi(argv[2]);
    int n, i, leidos;
    struct stat datos;
    char nombre[200];
    char buffer[tam];

    archivo = open(argv[1], O_RDONLY);
    stat(argv[1], &datos);
    n = (datos.st_size + tam - 1) / tam;

    for (i = 0; i < n; i++) {
        pipe(tubo);

        if ((pid = fork()) == 0) {
            close(tubo[1]);
            sprintf(nombre, "%s.h%02d", argv[1], i);
            salida = open(nombre, O_WRONLY | O_CREAT | O_TRUNC, 0666);

            while ((leidos = read(tubo[0], buffer, tam)) > 0)
                write(salida, buffer, leidos);

            close(tubo[0]);
            close(salida);
            exit(0);
        }

        close(tubo[0]);
        leidos = read(archivo, buffer, tam);
        write(tubo[1], buffer, leidos);
        close(tubo[1]);
        wait(NULL);
    }

    close(archivo);
    return 0;
}
