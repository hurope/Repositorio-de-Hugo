#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main(int argc, char *argv[])
{
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);
    int i, j, pid, shmid;
    int *finales;
    int padres[x + 1];

    shmid = shmget(IPC_PRIVATE, y * sizeof(int), IPC_CREAT | 0666);
    finales = (int *)shmat(shmid, 0, 0);
    padres[0] = getpid();

    for (i = 0; i < x; i++) {
        if (fork() == 0) {
            padres[i + 1] = getpid();
        } else {
            wait(NULL);
            if (i == 0) {
                printf("Soy el superpadre (%d): mis hijos finales son:", getpid());
                for (j = 0; j < y; j++)
                    printf(" %d", finales[j]);
                printf("\n");
                shmdt(finales);
                shmctl(shmid, IPC_RMID, 0);
                exit(0);
            }
            exit(0);
        }
    }

    for (i = 0; i < y; i++) {
        if (fork() == 0) {
            finales[i] = getpid();
            printf("Soy el subhijo %d, mis padres son:", getpid());
            for (j = 0; j <= x; j++)
                printf(" %d", padres[j]);
            printf("\n");
            exit(0);
        }
    }

    for (i = 0; i < y; i++)
        wait(NULL);

    shmdt(finales);
    exit(0);
}
